<?php

namespace Drupal\flipping_book\Form;

use Drupal\Core\Entity\ContentEntityDeleteForm;

/**
 * Provides a form for deleting Flipping Book entities.
 *
 * @ingroup flipping_book
 */
class FlippingBookDeleteForm extends ContentEntityDeleteForm {


}
