<?php

namespace Drupal\flipping_book;

use Drupal\content_translation\ContentTranslationHandler;

/**
 * Defines the translation handler for flipping_book.
 */
class FlippingBookTranslationHandler extends ContentTranslationHandler {

  // Override here the needed methods from ContentTranslationHandler.

}
